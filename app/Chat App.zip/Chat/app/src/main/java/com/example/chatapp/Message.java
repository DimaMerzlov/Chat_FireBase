package com.example.chatapp;

public class Message {
    private String author;
    private String textOfMessage;

    public Message(String author, String textOfMessage) {
        this.author = author;
        this.textOfMessage = textOfMessage;
    }

    public Message() {
    }

    public String getAuthor() {
        return author;
    }

    public String getTextOfMessage() {
        return textOfMessage;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTextOfMessage(String textOfMessage) {
        this.textOfMessage = textOfMessage;
    }
}
